use airline_db;

select * from flight_detail limit 10;	
select * from carrier_detail;

select * from route_detail limit 10;
select * from airport_detail limit 10;

select * from cancellation limit 10;
select * from state_detail limit 10;

# 1.	Find out the airline company which has a greater number of flight movement.
      
      select
	  carrier_detail.Carrier_ID,
      carrier_detail.Carrier_code as Company_name,
      flight_detail.Actualelaspedtime as Flight_movement_elapsedtime
      from flight_detail
      left join carrier_detail
      on Carrier_detail.Carrier_ID = flight_detail.carrierID
      group by carrier_detail.Carrier_code
      order by (flight_detail.Actualelaspedtime)desc;
          
      
#2.	Get the details of the first five flights that has high airtime.
select 
      FlightId,
      airtime from flight_detail 
      order by airtime desc limit 5; 
      
#3.	Compute the maximum difference between the scheduled and actual arrival and departure time for the flights and categorize it by the airline companies.
  #3.a) Maximum Difference with respect to Arrival Time:   
    select
	  carrier_detail.Carrier_ID,
      carrier_detail.Carrier_code as Company_name,
      flight_detail.ScheduledArrivaltime,
      flight_detail.Arrivaltime as Actual_ArrivalTime,
      flight_detail.arrivaldelay
      from flight_detail
      left join carrier_detail
      on Carrier_detail.Carrier_ID = flight_detail.carrierID
      group by carrier_detail.Carrier_code
      order by (flight_detail.arrivaldelay)desc;   

  #3.b) Maximum Difference with respect to Departure Time:   
    select
	  carrier_detail.Carrier_ID,
      carrier_detail.Carrier_code as Company_name,
      flight_detail.Scheduleddeparturetime,
      flight_detail.departuretime as Actual_DepartureTime,
      flight_detail.departuredelay
      from flight_detail
      left join carrier_detail
      on Carrier_detail.Carrier_ID = flight_detail.carrierID
      group by carrier_detail.Carrier_code
      order by (flight_detail.departuredelay)desc;   
      
 #4.	Find the month in which the flight delays happened to be more.
     #4.a) Maximum Arrival Delay in particular Month
     select
          flight_month,
          arrivaldelay
       from flight_detail
       order by arrivaldelay desc;
     
	#4.a) Maximum Departure Delay in particular Month
     select
          flight_month,
          departuredelay
       from flight_detail
       order by departuredelay desc;
       
  #5.	Get the flight count for each state and identify the top 1.  
	select
           state_detail.stateId,
           state_detail.state_code as State_Name,
           carrier_detail.Carrier_ID as flight_count
           from state_detail
           left join airport_detail
           on state_detail.stateId=airport_detail.stateId
           left join route_detail
           on airport_detail.locationId=route_detail.origincode
           left join flight_detail
           on route_detail.route_ID=flight_detail.routeId
           left join carrier_detail
           on flight_detail.carrierId=carrier_detail.Carrier_ID
           group by state_code
           order by (flight_count)desc;
           
#9.	Identify the routes that has more delay time.  
    select
          route_detail.route_ID,
          flight_detail.actualelaspedtime,
          flight_detail.arrivaldelay,
          flight_detail.departuredelay
          from flight_detail
          left join route_detail
          on flight_detail.routeId=route_detail.route_ID;
          
  #12.	Compute the maximum, minimum and average TaxiIn and TaxiOut time.
        select
            max(taxiIn),
            max(taxiOut)
             from flight_detail;
         select
            min(taxiIn),
            min(taxiOut)
             from flight_detail;    
         select
            avg(taxiIn),
            avg(taxiOut)
             from flight_detail;    
             
#17.	Get the route details with airline company code ‘AQ’       
        select
             flight_detail.routeId,
             carrier_detail.Carrier_code as airline_company,
             route_detail.origincode,
             route_detail.destinationcode
          from carrier_detail
          left join flight_detail
          on flight_detail.carrierId=carrier_detail.Carrier_ID
          left join route_detail
          on route_detail.route_ID=flight_detail.routeID
          where Carrier_code='AQ';
  
  #15.	Get details of flight whose speed is between 400 to 600 miles/hr for each airline company.
        select
             * from flight_detail
             where speed between 400 and 600 limit 50;
             
  #13. Get the details of origin and destination with maximum flight movement.     
        select
             flight_detail.routeId,
             carrier_detail.Carrier_code as airline_company,
             route_detail.origincode,
             route_detail.destinationcode,
             flight_detail.carrierId as flight_movement
          from carrier_detail
          left join flight_detail
          on flight_detail.carrierId=carrier_detail.Carrier_ID
          left join route_detail
          on route_detail.route_ID=flight_detail.routeID
          group by origincode, destinationcode
          order by (flight_detail.carrierId)desc;

#11.	Identify at which part of day flights arrive late.
        select
              Arrivaltime,
              ScheduledArrivaltime,
              arrivaldelay
          from flight_detail
          where arrivaldelay>60 limit 100;
              
#7. 	Find the dates in each month on which the flight delays are more. (note- assumed more as greater than 60 mins)
        select
             flight_date,
             flight_month,
             arrivaldelay,
             departuredelay
         from flight_detail
         where arrivaldelay > 60
         and departuredelay > 60;

#6.	    A customer wants to book a flight under an emergency situation. Which airline would you suggest him to book. Justify your answer.
    #Ans: I will suggest 'WN' Airline Company's flight, as it has lesser delay time and more over it is before time. And all top 5 results are of same company.
         select
	         carrier_detail.Carrier_ID,
             carrier_detail.Carrier_code as Company_name,
			 flight_detail.ScheduledArrivaltime,
             flight_detail.Arrivaltime as Actual_ArrivalTime,
             flight_detail.arrivaldelay,
             flight_detail.departuredelay
             from flight_detail
             left join carrier_detail
             on Carrier_detail.Carrier_ID = flight_detail.carrierID
             where (flight_detail.arrivaldelay)<10
             and departuredelay<10 limit 5;   
             
#10.	Find out on which day of week the flight delays happen more.           
         select
               distinct (dayweek),
               arrivaldelay,
               departuredelay
           from flight_detail
			where arrivaldelay > 60
           and departuredelay >60 ;
               
  #16.	Identify the best time in a day to book a flight for a customer to reduce the delay.
         select
              departuretime,
              Scheduleddeparturetime,
              departuredelay
             from flight_detail
             where departuredelay <10 limit 10;
             
  #18.	Identify on which dates in a year flight movement is large.
         select
	          carrier_detail.Carrier_ID,
              carrier_detail.Carrier_code as Company_name,
              flight_detail.flight_date,
              flight_detail.flight_year,
              flight_detail.Actualelaspedtime as Flight_movement_elapsedtime
            from flight_detail
            left join carrier_detail
            on Carrier_detail.Carrier_ID = flight_detail.carrierID
            group by carrier_detail.Carrier_code
            order by (flight_detail.Actualelaspedtime)desc;
      
    #14.	Find out which delay cause occurrence is maximum.
    #19.	Find out which delay cause is occurring more for each airline company.
		   select
	         carrier_detail.Carrier_ID,
             carrier_detail.Carrier_code as Company_name,
             flight_detail.ScheduledArrivaltime,
             flight_detail.Arrivaltime as Actual_ArrivalTime,
             flight_detail.arrivaldelay,
             flight_detail.Scheduleddeparturetime,
             flight_detail.departuretime as Actual_DepartureTime,
             flight_detail.departuredelay
           from flight_detail
           left join carrier_detail
            on Carrier_detail.Carrier_ID = flight_detail.carrierID
		    group by carrier_detail.Carrier_code
            having max(arrivaldelay) and max(departuredelay);
            
    #20.	 Write a query that represent your unique observation in the database. (pending)
           
	# 8.	Calculate the percentage of flights that are delayed compared to flights that arrived on time. (pending)
    
    
    